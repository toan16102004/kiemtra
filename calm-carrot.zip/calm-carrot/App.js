import React from 'react';
import { Text, SafeAreaView, StyleSheet } from 'react-native';
import { Card } from 'react-native-paper';
import AssetExample from './components/AssetExample';

export default function App() {
  return (
   <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Thông tin cá nhân
      </Text>
      <Text style={styles.text}>
        Họ và Tên: Nguyễn Tấn Toàn
      </Text>
      <Text style={styles.text}>
        Số điện thoại: 0812197745
      </Text>
      <Text style={styles.text}>
        Mã số sinh viên: 220501020
      </Text>
      <Text style={styles.text}>
        Email: 220501020@student.bdu.edu.vn
      </Text>
      <Text style={styles.text}>
        Sở thích: Chơi điện tử, xem video giải trí,...
      </Text>
      <Card> 
        <AssetExample />
      </Card>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  text: {
    fontSize: 16,
    textAlign: 'center',
  },
});